/*#include <avr/io.h>
#include "LED1s.h"
/*
void intializare()
{
	DDRB |= 0x10;
	
}
void aprinde_led()
{
	PORTB |= 0x10;
}
void stinge_led()
{
	PORTB &=~(0x10);
}*/