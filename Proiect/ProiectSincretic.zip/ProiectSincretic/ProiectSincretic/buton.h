/*
 * buton.h
 *
 * Created: 1/18/2017 11:20:54 AM
 *  Author: didi
 */ 


#ifndef BUTON_H_
#define BUTON_H_

void functionare_buton();
void initializare_buton();



#endif /* BUTON_H_ */