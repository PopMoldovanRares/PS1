
#ifndef TIMER0_H_
#define TIMER0_H_


void timer0Initializare();
ISR(TIMER0_OVF_vect);

#endif /* TIMER0_H_ */