/*
 #ifndef LED_H_
 #define LED_H_

 //#define LEDS 0x10

 void aprinde_led();
 void stinge_led();
 void intializare();


 #endif /* LED_H_ */