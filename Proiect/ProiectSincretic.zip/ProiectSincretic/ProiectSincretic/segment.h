
#ifndef SEGMENT_H_
#define SEGMENT_H_

#define e 0x01
#define d 0x02
#define c 0x04
#define g 0x10
#define f 0x20
#define a 0x40
#define b 0x80


//void initializare_segment();
void nr0();
void nr1();
void nr2();
void nr3();
void nr4();
void nr5();
void nr6();
void nr7();
void nr8();
void nr9();

#endif /* SEGMENT_H_ */